#pragma once
#include "Runtime/Core/Public/Modules/ModuleInterface.h"
#define DIALOGUEPLUGIN_MODULE_NAME "DialoguePlugin"

class IDialoguePluginModuleInterface : public IModuleInterface
{
};

